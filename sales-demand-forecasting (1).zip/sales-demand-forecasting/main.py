import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
import pickle
import os

os.makedirs("models", exist_ok=True)
os.makedirs("outputs", exist_ok=True)

data = pd.read_csv("data/sales_data.csv")

print("\nFirst 5 Rows:")
print(data.head())

data['Date'] = pd.to_datetime(data['Date'])

data['Day'] = data['Date'].dt.day
data['Month'] = data['Date'].dt.month
data['Year'] = data['Date'].dt.year

data['Time_Index'] = np.arange(len(data))

print("\nProcessed Data:")
print(data.head())

X = data[['Time_Index']]
y = data['Sales']

model = LinearRegression()

model.fit(X, y)

print("\nModel Training Completed")

data['Predicted_Sales'] = model.predict(X)

mae = mean_absolute_error(y, data['Predicted_Sales'])
mse = mean_squared_error(y, data['Predicted_Sales'])
rmse = np.sqrt(mse)

print("\nEvaluation Metrics")
print("MAE :", round(mae, 2))
print("MSE :", round(mse, 2))
print("RMSE:", round(rmse, 2))

future_days = 10

future_index = np.arange(len(data), len(data) + future_days)

future_predictions = model.predict(
    future_index.reshape(-1, 1)
)

future_dates = pd.date_range(
    start=data['Date'].max() + pd.Timedelta(days=1),
    periods=future_days
)

forecast_df = pd.DataFrame({
    'Date': future_dates,
    'Forecasted_Sales': future_predictions
})

print("\nFuture Forecast:")
print(forecast_df)

forecast_df.to_csv(
    "outputs/predictions.csv",
    index=False
)

print("\nPredictions saved successfully")

with open("models/sales_model.pkl", "wb") as file:
    pickle.dump(model, file)

print("Model saved successfully")

plt.figure(figsize=(12, 6))

plt.plot(
    data['Date'],
    data['Sales'],
    label='Actual Sales',
    marker='o'
)

plt.plot(
    data['Date'],
    data['Predicted_Sales'],
    label='Predicted Sales',
    linestyle='--'
)

plt.plot(
    forecast_df['Date'],
    forecast_df['Forecasted_Sales'],
    label='Future Forecast',
    marker='o'
)

plt.title("Sales Forecasting")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.legend()
plt.grid(True)

plt.savefig("outputs/forecast_plot.png")

plt.show()

print("\nForecast graph saved successfully")